package com.temporary.mvpdemo.ui.main;

import com.temporary.mvpdemo.ui.base.BaseView;

public interface MainContractor {

    interface View extends BaseView {

    }

    interface Presenter {

    }

}
