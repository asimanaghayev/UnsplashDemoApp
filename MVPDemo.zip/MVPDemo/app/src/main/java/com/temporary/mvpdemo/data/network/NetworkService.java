package com.temporary.mvpdemo.data.network;


import com.temporary.mvpdemo.data.network.model.Photos;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface NetworkService {

    @GET("/photos/")
    Call<Photos> getPhotosFromApi(
            @Query("client_id") String clientId
    );
}