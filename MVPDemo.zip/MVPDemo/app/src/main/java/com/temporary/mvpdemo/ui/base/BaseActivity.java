package com.temporary.mvpdemo.ui.base;

import android.support.v7.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity implements BaseView {


}
