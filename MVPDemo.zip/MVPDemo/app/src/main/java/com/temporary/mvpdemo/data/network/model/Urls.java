package com.temporary.mvpdemo.data.network.model;

import com.google.gson.annotations.SerializedName;

public class Urls {
    @SerializedName("raw")
    private String raw;

    @SerializedName("full")
    private String full;

    @SerializedName("regular")
    private String regular;

    @SerializedName("small")
    private String small;

    @SerializedName("thumb")
    private String thumb;
}
