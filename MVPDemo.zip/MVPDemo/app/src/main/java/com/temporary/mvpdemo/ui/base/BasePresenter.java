package com.temporary.mvpdemo.ui.base;

public class BasePresenter implements MvpPresenter{

}
