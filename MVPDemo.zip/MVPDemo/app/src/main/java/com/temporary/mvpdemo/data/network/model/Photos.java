package com.temporary.mvpdemo.data.network.model;

import com.google.gson.annotations.SerializedName;

public class Photos {
    @SerializedName("author")
    private String mAuthor;

    @SerializedName("width")
    private int width;

    @SerializedName("height")
    private int height;

    @SerializedName("color")
    private int color;

    @SerializedName("alt_description")
    private String alt_description;

    @SerializedName("urls")
    private Urls urls;

    @SerializedName("likes")
    private int likes;
}
