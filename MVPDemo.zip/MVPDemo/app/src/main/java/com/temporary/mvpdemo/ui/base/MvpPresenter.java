package com.temporary.mvpdemo.ui.base;

public interface MvpPresenter {

}
