package com.temporary.mvpdemo.ui.main;

import com.temporary.mvpdemo.ui.base.BasePresenter;

public class MainPresenter extends BasePresenter implements MainContractor.Presenter {

    private MainContractor.View view;

    public MainPresenter(MainContractor.View view) {
        this.view = view;
    }

    public void setView(MainContractor.View view) {
        this.view = view;
    }


}
