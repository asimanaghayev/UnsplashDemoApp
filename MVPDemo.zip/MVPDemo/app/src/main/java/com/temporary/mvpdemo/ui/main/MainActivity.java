package com.temporary.mvpdemo.ui.main;

import android.os.Bundle;

import com.temporary.mvpdemo.R;
import com.temporary.mvpdemo.ui.base.BaseActivity;

public class MainActivity extends BaseActivity implements MainContractor.View {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
